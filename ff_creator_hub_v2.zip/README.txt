FF Creator Hub V2 — single-file private website. Open index.html in a browser. Data stays in localStorage; no server required.
